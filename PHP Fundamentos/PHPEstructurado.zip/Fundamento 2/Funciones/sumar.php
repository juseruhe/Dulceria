<?php


function Sumar($a,$b){

$suma = $a+ $b;

return $suma;



}


echo Sumar(8,20);
?>