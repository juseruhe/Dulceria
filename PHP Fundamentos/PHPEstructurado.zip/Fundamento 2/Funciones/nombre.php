<?php


function Hola($nombre){

$saludo =  "Hola ".$nombre;

return $saludo;



}


echo Hola("Juan");
?>