<?php


$dulces = array(
"Chocolatina" => array(
"Cantidad" => 3500,
"Unidades_Vendidas" => 1000), 
"Barilete" => array(
"Cantidad" => 1500,
"Unidades_Vendidas" => 500
)
);


echo "Cantidad de Bariletes es: ".$dulces["Barilete"]["Cantidad"]."<br>";

echo "Las Unidades Vendidas de Chocolatina es: ".$dulces["Chocolatina"]["Unidades_Vendidas"];



?>