<?php


$dulces = array(40,100,80);

var_dump($dulces);









?>