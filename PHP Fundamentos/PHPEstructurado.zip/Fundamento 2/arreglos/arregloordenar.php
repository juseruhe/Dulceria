<?php

$dulces = array(20,30,40,35);

rsort($dulces);

sort($dulces);

var_dump($dulces);








?>