<?php


$dulces = array("ChocoBreaks","Barilete","Caramelo");

var_dump($dulces);












?>