<?php



$dulces = array("Caramelo" =>450,"Jet"=> 500, "Chicles" => 400);

foreach ($dulces as $nombre => $cantidad ){
    echo "$nombre".":".$cantidad.":"."<br>";
}








?>