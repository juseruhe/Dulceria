<?php


$dulces = array("ChocoBreaks" => 100, "Jet" => 452, "Paletas" => 250);


$dulces["ChocoBreaks"] = 1500;

$dulces["Jet"] = 240;


echo "La cantidad de Chocolatinas Jet ".$dulces["Jet"];





?>