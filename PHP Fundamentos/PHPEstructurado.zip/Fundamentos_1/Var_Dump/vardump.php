<?php

$numero = 8.459;

var_dump($numero);









?>