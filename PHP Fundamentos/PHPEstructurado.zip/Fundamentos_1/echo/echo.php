<?php

echo time();













?>