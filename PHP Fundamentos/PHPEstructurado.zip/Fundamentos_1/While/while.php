<?php

$nombre = 1;

while($nombre < 11){

echo "jaja <br>";

$nombre++;

}

$hola = 5;

do {

    echo "<br> Hola <br>";

}


while ($hola <= 10);



?>