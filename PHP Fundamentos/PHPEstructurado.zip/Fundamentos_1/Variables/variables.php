<?php

echo "Hola desde VSC a la Dulcería";

echo time();


$Entero = 123;
$Flotante= 4.58;
$Cadena = "Hola soy Juan";
$Booleano = TRUE;
$br = "<br>";
echo "$Entero\n";
echo "$Flotante.$br";
echo "$Cadena.$br";
echo "$Booleano.$br";











?>