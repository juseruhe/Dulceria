<?php


$rand = rand(1,3);
switch($rand){

case 1: echo "Fuera ".$rand;
break;

case 2: echo "Medio " .$rand;
break;

case 3: echo "Adentro ".$rand;
break;

default: "No existe";

}














?>