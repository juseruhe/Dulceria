<?php

if(isset($_POST["producto"])){

$producto = $_POST["producto"];
echo "Producto: ".$producto. " <Br>";


}


if(isset($_POST["password"])){

    $password = $_POST["password"];
    echo "Password: ".$password. " <Br>";
    
    
    }



    if(isset($_POST["contabilizar"])){

        $contabilizar = $_POST["contabilizar"];
        echo "Contabilizar: ".$contabilizar. " <Br>";
        
        
        }






?>