<?php

if(isset($_GET["producto"])){

$producto = $_GET["producto"];
echo "Producto: ".$producto. " <Br>";


}


if(isset($_GET["password"])){

    $password = $_GET["password"];
    echo "Password: ".$password. " <Br>";
    
    
    }



    if(isset($_GET["contabilizar"])){

        $contabilizar = $_GET["contabilizar"];
        echo "Contabilizar: ".$contabilizar. " <Br>";
        
        
        }






?>